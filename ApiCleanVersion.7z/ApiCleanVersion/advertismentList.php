<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $url = "http://apiconnection.cloudapp.net/Service1.svc?singleWsdl";     
        $client = new SoapClient($url);
        ?>
        <table  border="1">
            <tr>
                <th>Owner</th>
                <th>Address</th>
                <th>Expiration Date</th>
            </tr>            
            <?php
            $idCounter = 0;
            $result = $client->GetAllAds();
            // Self generated table rows with the content of the advertisements
            foreach($result->GetAllAdsResult->Ads as $adsResult){
                        echo "<tr>";
                        echo "<td>";
                        print_r($adsResult->Owner);
                        echo "</td>";
                        echo "<td>";
                        print_r($adsResult->Address);
                        echo "</td>";
                        echo "<td>";
                        print_r($adsResult->dateOfExpire);
                        echo "</td>";                       
            }
            ?>
        </table> 
        <form action='pageMovement.php' method='post'>
            <input type='submit' name="return" value="Return to Main">
        </form>
    </body>
</html>
