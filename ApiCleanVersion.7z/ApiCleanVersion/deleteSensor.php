<?php
$testId = $_POST['sensorId'];
$url = "http://apiconnection.cloudapp.net/Service1.svc?singleWsdl";     
        $client = new SoapClient($url);
            
            $result = $client->GetAllMovementSensors();
            $randomCounter = 0;
foreach($result->GetAllMovementSensorsResult->MovementSensor as $sensor){
    if($randomCounter == $testId){
        $client->__soapCall("DeleteSpecificSensor", array("DeleteSpecificSensorResponse" => array("id" => $sensor->ID)));
header("Location: ../ApiCleanVersion/adminMainPage.php");
    }
    $randomCounter++;
    echo "error";
}

