<?php
if(isset($_POST['submit'])){
    header('Location: ../ApiCleanVersion/login.php');
}
if(isset($_POST['submit2'])){
    header('Location: ../ApiCleanVersion/advertismentList.php');
}
if(isset($_POST['return'])){
    header('Location: ../ApiCleanVersion/clientMainPage.php');
}