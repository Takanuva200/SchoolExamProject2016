<?php
$testId = $_POST['mapId'];

echo '<iframe  width="450"
  height="250" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAmHSeMpvICzdru_pyeQHvDRFsS_oCSLhc &q=' . $testId . '">
  </iframe>';
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

