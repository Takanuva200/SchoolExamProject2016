<html>
    <head>
        <meta charset="UTF-8">
        <title>Client main page</title>
    </head>
    <body>
        <h1>Welcome to the client main page</h1>
        <form action='pageMovement.php' method='post'>
            <input type='submit' name="submit" value="Log out">
            <input type='submit' name="submit2" value="Advertisement list">
            
        </form>
        
        <h3>Ads Table</h3>
        <table>
            <tr>
                <th>Owner</th>
                <th>Address</th>
                <th>Expiration Date</th>
                <th>Map</th>               
            </tr>            
            <?php
            $url = "http://apiconnection.cloudapp.net/Service1.svc?singleWsdl";     
        $client = new SoapClient($url);
            $idCounter = 0;
            $result = $client->GetAllAds();
            // Self generated table rows with the content of the advertisements
            foreach($result->GetAllAdsResult->Ads as $adsResult){
                $value = $adsResult->Address;
                        echo "<tr>";
                        echo "<td>";
                        print_r($adsResult->Owner);
                        echo "</td>";
                        echo "<td>";
                        print_r($adsResult->Address);
                        echo "</td>";
                        echo "<td>";
                        print_r($adsResult->dateOfExpire);
                        echo "</td>";
                        
                        echo "<form action='mapApi.php' method='post'>";
                        echo "<input type='text' value='" . $value . "'name='mapId' hidden>";
                        echo "<td> <input type='submit' value='See on Map'></td>";
                        echo "</form>";
                        $idCounter++;
            }
            ?>
        </table> 
        <?php
        // put your code here
        ?>
    </body>
</html>
